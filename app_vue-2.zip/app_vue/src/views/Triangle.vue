<!--<template>
    <div class="SecondPrices">
        <h4>{{ title }}</h4>
        <TriangleCard
            v-for="price in pricingBoxes"
            :price="price"
        />
        
    </div>
</template>
<script setup>
import { reactive } from 'vue';
import TriangleCard from '../components/TriangleCard.vue';
const pricingBoxes = reactive([
    {
        title:'Online coaching lessons for remote learning.',
    }
])
</script>
<style>
  .SecondPrices{
    background-color: aqua;
  }
</style>-->