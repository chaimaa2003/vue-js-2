<template>
    <h1>Affordable pricing</h1>
    <br>
    <div class="prices">
        
        <PricingCard
            v-for="price in pricingBoxes"
            :price="price"
        />
        
    </div>
    <br>
    <div class="Triangle">
        
      <TriangleCard />
        
    </div>
    <br>
    <div class="Wrapper">
        <wrapper  
            v-for="drop in dropBox"
            :drop="drop"
        />
    </div>
    

</template>
<script setup>
import { reactive } from 'vue';
import { reactive2 } from 'vue';
import PricingCard from '../components/pricingCard.vue';
import TriangleCard from '../components/TriangleCard.vue';
import wrapper from '../components/wrapper.vue';
// ** i use reactive function insted of return data object



const pricingBoxes = reactive([
    {
        title1:'Like a pussy',
        title: 'Free',
        suptitle:'FOREVER',
        spicifications: 
            
                    [
                        'Components-driven system', 
                        'Sales-boosting landing pages',
                        'Awesome Feather icons pack',
                      ],
        button:"Try for free",
                     
    },
        
       
    

    {
        title1:'👤 Individual',
        button1:"BEST!",
        title: '$24',
        suptitle:'FOREVER',
        spicifications: [
             
                    'Components-driven system',
                    'Sales-boosting landing pages',
                    'Awesome Feather icons pack',
                    'Themed into 3 different style',
                    'Will help to learn Figma'
                ] ,
                  
        button:"Reguler license",
           
       
    },   
        
    {
        title1:'👥 Corporate',
        title: '$12',
        suptitle:'FOREVER',
        spicifications: [
            
           
                'Components-driven system',
                'Sales-boosting landing pages',
                'Awesome Feather icons pack',
                'Themed into different style',
        ],
        
        button:"Extended license",
    },
]);

const dropBox = reactive2([
    {
        title: 'Lorem ipsum dolor sit amet',
        Text: [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do',
            'eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur ',
            'adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet',
            'consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod tempor',
            ]
    },
    {
        title: 'Lorem ipsum dolor sit amet',
        Text: [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do',
            'eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur ',
            'adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet',
            'consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod tempor',
            ]
    },
    {
        title: 'Lorem ipsum dolor sit amet',
        Text: [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do',
            'eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur ',
            'adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet',
            'consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod tempor',
            ]
    },
    {
        title: 'Lorem ipsum dolor sit amet',
        Text: [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do',
            'eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur ',
            'adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet',
            'consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod tempor',
            ]
    },
    {
        title: 'Lorem ipsum dolor sit amet',
        Text: [
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do',
            'eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur ',
            'adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod temporLorem ipsum dolor sit amet',
            'consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor sitamet, consectetur adipiscing elit, sed do eiusmod tempor',
            ]
    },
])

</script>
<style scoped>
/* Add This styling */
.prices {
    display: flex;
    gap: 50px;
    justify-content: center;
    height: 472px;
   

}
h1 {
color: #49BBBD;
text-align: center;
font-family: Arial, Helvetica, sans-serif;
font-size: 64px;
font-style: normal;
font-weight: 800;
line-height: normal;
letter-spacing: -1px;
height: 130px;
}
.Triangle {
    width: 90%;
    height: 323px;
    flex-shrink: 0;
    border-radius: 37px;
    background: #252641;
    justify-content: center;
    left: 5px;
   text-align: center;
   align-items: center;
    flex-direction: row;
    margin: 5%;
}
h2{
    color: #2D3436;
    font-family: Poppins;
    font-size: 36px;
    font-style: normal;
    font-weight: 600;
    line-height: normal;
    widows: 827;
    text-align: center;
    height: 54px;
}
.wrapper{
    width: 90%;
    height: 4981px;
    background-color: rgb(196, 31, 31);
    margin: 5%;
    
}
</style>
