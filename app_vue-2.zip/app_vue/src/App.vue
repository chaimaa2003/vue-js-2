<template>
    <div>
        <!-- Navbar -->
        <Navbar />
        <!-- Header Title -->
        <!-- Pricing Boxes -->
        <PricingPage />
    </div>
</template>

<script setup>
import Navbar from './components/Navbar.vue';
import PricingPage from './views/pricing.vue';
</script>

<style >

</style>
