<template>
    <!-- I move h1 h2 into a div -->
    <div class="app">
       <div class="myCard">
        <div class="secondC">
            <h4>{{ this.price.title1 }}</h4>
            <button v-if="this.price.title=== '$24'" class="button1">{{ this.price.button1 }}</button>
        </div>
        <h1>{{ this.price.title }}  <span class="supT" >/ {{ this.price.suptitle }} </span></h1>
        <div class="card" v-for="spicification in this.price.spicifications">
            
            <div class="rapper" >
             <i class="gg-check-o" :class="price.title === 'Free' ? 'grey-icon' : price.title === '$24' ? 'pink-icon' : price.title === '$12' ? 'blue-icon' : ''"></i>
            <span class="text">{{ spicification }}</span>

            </div>
        
        </div> 
        
       </div>
       <button class="button">{{ this.price.button }}</button>
       
    </div>

    
</template>

<script>
export default {
    name: 'card',
    props: {
        price: Object,
    },
};
</script>

<style scoped>

  @import url('https://fonts.googleapis.com/css2?family=Akronim&family=DM+Sans:wght@400;700&family=Gulzar&family=Inter&display=swap');
  


.app {
    padding: 1.5rem 2rem;
    border-radius: 5px;
    font-size: 70%; 
    line-height: 40px;
    width: 360px;
    height: 442px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    
}
.app:hover{
    box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
}

h4{
    
 color: #49BBBD;
/* 18 sp • Paragraph Bold */
 font-family: Inter;
 font-size: 13px;
 font-style: normal;
 font-weight: 700;
 line-height: 32px; /* 177.778% */
 letter-spacing: 0.2px;
 width: 216px;
height: 32px;
}

h1 {
 color: var(--Black, #2D3436);
/* 48 sp • H3 Heading */
font-family: Inter;
font-size: 48px;
font-style: normal;
font-weight: 700;
line-height: 56px; /* 116.667% */
letter-spacing: -1px;
}
.card{

}


.rapper{
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 10px;
    margin-top: 1rem;
  
    
}

.gg-check-o {
    box-sizing: border-box;
    position: relative;
    display: block;
    transform: scale(var(--ggs,1));
    width: 22px;
    height: 22px;
    border: none;
    border-radius: 100px;
    background-color:rgb(206, 202, 202);
    display:flex;

 
 
}

.text{
color: var(--Black, #2D3436);
/* 18 sp • Paragraph Default */
font-family: 'Inter', sans-serif;
font-size: 18px;
font-style: normal;
font-weight: 400;
line-height: 32px;
}

.gg-check-o::after {
 content: "";
 display: block;
 box-sizing: border-box;
 position: absolute;
 left: 5px;
 top: 0px;
 width: 6px;
 height: 10px;
 border-color: currentColor;
 border-width: 0 2px 2px 0;
 border-style: solid;
 transform-origin: bottom left;
 transform: rotate(45deg);
 
 /*Why this property is bloked */
 justify-content: center;
 align-items: center;
}
.grey-icon{
    background-color: #c2c2c2;
} 
.pink-icon{
    background-color: #FDCB6E;
}
.blue-icon{
    background-color: #55efc4 ;
}
.supT{
color: #6C5CE7;
/* 12 sp • MINICAPS */
font-family: Inter;
font-size: 12px;
font-style: normal;
font-weight: 800;
line-height: normal;
letter-spacing: 2.5px;
text-transform: uppercase;
}
.button{
    

width: 100%;
height: 48px;
color: #49BBBD;
text-align: center;
font-family: Inter;
font-size: 18px;
font-style: normal;
font-weight: 700;
line-height: 32px; 
letter-spacing: 0.2px;
background-color: white;
border: 1px solid #807b7b;
border-radius: 10px;
padding: 0px;

}
.button:hover{
    background-color: #49BBBD;
    color:white;
}
.secondC{
    display: flex;
}
.button1{
    border: 2px solid #6C5CE7;
    border-radius: 12px;
    padding: 5px;
    width: 90px;
    height: 32px;
    flex-shrink: 0;
    background-color: white;
}



</style>
