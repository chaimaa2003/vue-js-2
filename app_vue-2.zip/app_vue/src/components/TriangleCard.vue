<template>
   <div>
    <div class="Triangle">
            <h1>Online coaching lessons for remote learning.</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempos Lorem ipsum dolor
                              sitamet,consectetur adipiscing elit, sed do eiusmod tempor
            </p>
        </div>
        
       
    
        <button class="button">Start learning now</button>
    </div>
</template>
<script >
    export default {
    name: 'TriangleCard',
};
</script>

<style scoped>
.Triangle{
    text-align: center;
    align-items: center;
    flex-direction: row;
}
h1 {
    color: #FFF;
    font-family: Poppins;
    font-style: normal;
    line-height: normal;
    display: block;
    text-align: center;
    width: 1473px;
    font-size: 37px;
    font-weight: 800;
    letter-spacing: -1px;
    height: 130px;
    margin-top: 2%;
    line-height: 468%;
}  
p{
    color: #FFF;
    text-align: center;
    font-family: Poppins;
    font-size: 25px;
    font-style: normal;
    font-weight: 400;
    line-height: 180%; /* 43.2px */
    letter-spacing: 0.48px;
    height: 126px;
    width: 1516px;
}
.button{


width: 17%;
height: 55px;
color: #49BBBD;
text-align: center;
font-family: Poppins;
font-size: 18px;
font-style: normal;
font-weight: 700;
line-height: 32px; 
letter-spacing: 0.2px;
background-color: white;
border: 1px solid #807b7b;
border-radius: 10px;
padding: 0px;
align-items: flex-end;
flex-direction: row;


}
.button:hover{
    background-color: #49BBBD;
    color:white;
}
</style>