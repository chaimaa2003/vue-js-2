<template>
        <h2>Online coaching lessons for remote learning</h2>
        <div class="collapsible">
            
                <label>{{this.drop.title}}</label>

                <img src="../assets/drop.svg" />
                
            </div>
            <div class="collapsible-text">
                <p>
                    {{ this.drop.Text }}
                </p>
            </div>
</template>

<script>
    export default{
        name:'Wrapper' ,
        props:{
        drop: Object
       }
    }
</script>
<style>
h2{
    width: 827px;
    color: #2D3436;
    font-family: Poppins;
    font-size: 36px;
    font-style: normal;
    font-weight: 600;
    line-height: normal;
    text-align: center;
}


</style>